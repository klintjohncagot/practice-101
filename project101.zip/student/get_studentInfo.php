<?php 
    require "./connect.php";
    session_start();

    $student_id = $_GET["student_id"];

    $sql = "SELECT * FROM student WHERE student_id = $student_id";
    $res = mysqli_query($conn, $sql);

    if($res) {
        $row = mysqli_fetch_assoc($res);

        $row["date_added"] = date("F d, Y", strtotime($row["date_added"]));

        // if($row["gender"] == "M"){
        //     $row["gender"] = "Male";
        // }else if($row["gender"] == "F"){
        //     $row["gender"] = "Female";
        // }

        if($row["year_level"] == 1){
            $row["year_level"] = "1st year";
        }else if($row["year_level"] == 2){
            $row["year_level"] = "2nd year";
        }else if($row["year_level"] == 3){
            $row["year_level"] = "3rd year";
        }else if($row["year_level"] == 4){
            $row["year_level"] = "4th year";
        }
        echo json_encode($row); 
    }
?>