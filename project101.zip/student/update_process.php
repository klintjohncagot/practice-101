<?php 
session_start();
require('./connect.php');
date_default_timezone_set('Asia/Manila');

$student_id = $_POST['student_id'];
$first_name = $_POST['first_name'];
$last_name = $_POST['last_name'];
$gender = $_POST['gender'];
$year_level = $_POST['year_level'];
$major = $_POST['major'];
$email = $_POST['email'];
$password = $_POST['password'];


//----  validations
$lettersRegex = "/[0-9]/";
$specialCharacterRegex  = "/[\\W_]/";
//--------------

if (preg_match($lettersRegex, $first_name, $match)) {
    echo json_encode("Numbers is not allowed. Please enter a valid first name.");
} else if (preg_match($lettersRegex, $last_name, $match)) {
    echo json_encode("Numbers is not allowed. Please enter a valid last name.");
}else {

    $password_encryption = password_hash($password, PASSWORD_DEFAULT);

    $update = "UPDATE student SET
                first_name = '$first_name',
                last_name = '$last_name',
                gender = '$gender',
                year_level = '$year_level',
                major = '$major',
                email = '$email',
                password = '$password_encryption'
    WHERE student_id = '$student_id'";
    $res = mysqli_query($conn, $update);

    if ($res) {
        echo json_encode("success");
    }else {
        echo json_encode("fail");
    }
}

?>


