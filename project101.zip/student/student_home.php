<?php
session_start();
require('connect.php');

if (isset($_SESSION['student_id'])) {
  $id = $_SESSION['student_id'];
} else {
  header("Location: ../index.php");
}

$sql = "SELECT * FROM student WHERE student_id =" . $id . "";
$res = mysqli_query($conn, $sql);

?>
<html>
    <head>
        <meta charset="UTF-8">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
        <title>STUDENT</title>
        <link href="css/style.min.css" rel="stylesheet">
        <link href="css/theme-colors.css" rel="stylesheet">
        <!-- Bootstrap core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <!-- Your custom styles (optional) -->
        <link href="css/mdb.min.css" rel="stylesheet">
        <link href="css/style.min.css" rel="stylesheet">
        <!-- <link rel="icon" href="./mobile/img/gym_logo.png"> -->
        <!-- <link href="index_admin.css" rel="stylesheet"> -->
        <link href="css/theme-colors.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
    </head>
    <style>
    
    </style>
    <body class="bg-dark">
        <div id="display_card" class="card mx-auto mt-5 bg-light" style="width: 50%">
            <div class="card-body">
                <h1 class="text-center">Student Information</h1>
                <?php 
                    $row = mysqli_fetch_array($res);
                    // echo "<strong>".$row['student_id']."</strong>";
                ?>
                <input type="text" style="display:none" readonly class="text-center form-control" id="hidden_student_id" value="<?= $row['student_id'] ?>" >
                <div class="container mt-5">
                    <div class="row">
                        <div class="col-6">
                            <label>First name</label>
                            <input type="text" id="display_first_name" class="form-control" readonly>
                        </div>
                        <div class="col-6">
                            <label>Last name</label>
                            <input type="text" id="display_last_name" class="form-control" readonly>
                        </div>
                    </div>
                </div>
                <div class="container mt-4">
                    <div class="row">
                        <div class="col-3">
                            <label>Gender</label>
                            <input type="text" id="display_gender" class="form-control" readonly>
                        </div>
                        <div class="col-3">
                            <label>Year level</label>
                            <input type="text" id="display_year_level" class="form-control" readonly>
                        </div>
                        <div class="col-6">
                            <label>Major</label>
                            <input type="text" id="display_major" class="form-control" readonly>
                        </div>
                    </div>
                </div>
                <div class="container mt-4">
                    <div class="row">
                        <div class="col-5">
                            <label>Email</label>
                            <input type="text" id="display_email" class="form-control" readonly>
                        </div>
                        <div class="col-4">
                            <label>Date Created</label>
                            <input type="text" id="display_date_created" class="form-control" readonly>
                        </div>
                        <div class="col-3">
                            <label>Time Created</label>
                            <input type="text" id="display_time_created" class="form-control" readonly>
                        </div>
                    </div>
                </div>

                <button type="button" class="btn btn-primary mt-4 ml-3" id="update-btn" >Update</button>
                <button type="button" class="btn btn-danger mt-4 ml-3" onclick="logout(this)" id="update-btn" >Logout</button>

            </div>
        </div>


        <div id="update_card" class="card mx-auto mt-5 bg-light" style="width: 50%; display: none;">
            <div class="card-body">
                <h1 class="text-center">Update Information</h1>
                <?php 
                    $row = mysqli_fetch_array($res);
                    // echo "<strong>".$row['student_id']."</strong>";
                ?>
                <div class="container mt-5">
                    <div class="row">
                        <div class="col-6">
                            <label>First name</label>
                            <input type="text" id="update_first_name" required name="first_name" class="form-control">
                        </div>
                        <div class="col-6">
                            <label>Last name</label>
                            <input type="text" id="update_last_name" required name="last_name" class="form-control">
                        </div>
                    </div>
                </div>
                <div class="container mt-4">
                    <?php
                        $sql_student = "SELECT * FROM student WHERE student_id = $id";
                        $res_student = mysqli_query($conn, $sql_student);
                        $row_student= mysqli_fetch_assoc($res_student);
                        // echo "<strong>" . $row['first_name'] . "</strong>";

                        if($row_student["year_level"] == 1){
                            $int_year_level = 1;
                            $row_student["year_level"] = "1st year";
                        }else if($row_student["year_level"] == 2){
                            $int_year_level = 2;
                            $row_student["year_level"] = "2nd year";
                        }else if($row_student["year_level"] == 3){
                            $int_year_level = 3;
                            $row_student["year_level"] = "3rd year";
                        }else if($row_student["year_level"] == 4){
                            $int_year_level = 4;
                            $row_student["year_level"] = "4th year";
                        }
                    ?>
                    <div class="row">
                        <div class="col-3">
                            <label>Gender</label>
                            <input type="text" id="update_gender" value="<?= $row_student["gender"] ?>" required name="gender" readonly class="form-control">
                        </div>
                        <div class="col-3">
                            <label>Year Level</label> <br />
                            <select name="year_level" id="update_year_level" class="form-control" aria-label="Default select example">
                                    <option selected value="<?= $int_year_level ?>"><?= $row_student["year_level"] ?></option>
                                    <option value="1">1st year</option>
                                    <option value="2">2nd year</option>
                                    <option value="3">3rd year</option>
                                    <option value="4">4th year</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <label>Major</label>
                            <input type="text" id="update_major" required class="form-control">
                        </div>
                    </div>
                </div>
                <div class="container mt-4">
                    <div class="row">
                        <div class="col-6">
                            <label>Email</label>
                            <input type="email" id="update_email" required class="form-control">
                        </div>
                        <div class="col-6">
                            <label>Password</label>
                            <input type="password" id="update_password" placeholder="Enter password" required class="form-control">
                        </div>
                    </div>
                </div>

                <div class="container mt-4">
                    <div class="row">
                        <div class="col-6">
                            <label>Date Created</label>
                            <input type="text" id="update_date_created" class="form-control" readonly>
                        </div>
                        <div class="col-6">
                            <label>Time Created</label>
                            <input type="text" id="update_time_created" class="form-control" readonly>
                        </div>
                    </div>
                </div>

                <button type="button" class="btn btn-success mt-4 ml-3" id="update_submit-btn" >Submit</button>
                <button type="button" class="btn btn-dark mt-4 ml-3"  id="cancel-btn" >Cancel</button>

            </div>
        </div>

    </body>
</html>

<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>
    <script type="text/javascript" src="js/popper.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/mdb.min.js"></script>
    <script type="text/javascript" src="validation.js"></script>
    <script src="./../js/pagination.js"></script>
    <script>

        function logout() {
            console.log("test logout btn");
            // AJAX Request
            let req = new XMLHttpRequest();
            req.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                window.location.href = "./logout_process.php";
                }
            }
            req.open('GET', './logout_process.php', true);
            req.send();
        }


        var student_id = document.getElementById("hidden_student_id").value;
        var studInfo;
        console.log(student_id);
        $.get("./get_studentInfo.php", { student_id: student_id } , function(res) {
            studInfo = JSON.parse(res);
        }).then(() => {
            renderStudent(studInfo);
        });

        function renderStudent(data) {
            // console.log(data.display_first_name);
            document.getElementById("display_first_name").value = data.first_name;
            document.getElementById("display_last_name").value = data.last_name;
            document.getElementById("display_gender").value = data.gender;
            document.getElementById("display_year_level").value = data.year_level;
            document.getElementById("display_major").value = data.major;
            document.getElementById("display_email").value = data.email;
            document.getElementById("display_date_created").value = data.date_added;
            document.getElementById("display_time_created").value = data.time_added;

            document.getElementById("update_first_name").value = data.first_name;
            document.getElementById("update_last_name").value = data.last_name;
            // document.getElementById("update_gender").value = data.gender;
            // document.getElementById("update_year_level").value = data.year_level;
            document.getElementById("update_major").value = data.major;
            document.getElementById("update_email").value = data.email;
            document.getElementById("update_date_created").value = data.date_added;
            document.getElementById("update_time_created").value = data.time_added;
        }

        $("#update-btn").click(function () {
            console.log("test update btn");
            $("#update_card").show();
            $("#display_card").hide();

        });

        $("#cancel-btn").click(function () {
            console.log("test cancel btn");
            $("#update_card").hide();
            $("#display_card").show();

        });


        $("#update_submit-btn").click(function () {
            var student_id_update = document.getElementById("hidden_student_id").value;
            console.log(student_id_update);
			$.confirm({
				type: 'modern',
				content: function () {
					var self = this;
					return $.post(
						"./update_process.php",
						{
							first_name: $("#update_first_name").val(),
							last_name: $("#update_last_name").val(),
                            gender: $("#update_gender").val(),
                            year_level: $("#update_year_level").val(),
                            major: $("#update_major").val(),
                            email: $("#update_email").val(),
                            password: $("#update_password").val(),
                            student_id: $("#hidden_student_id").val()
						},
                        
						function (res) {
                            console.log(res);
                            console.log(JSON.parse(res));
                            var response = JSON.parse(res);

                            if(response == "success") {
                                self.setTitle("Update Information");
                                self.setContent("Susuccessfully updated");
                                self.setType("green");
                                self.buttons.close.hide();
                                self.buttons.ok.hide();
                                setTimeout(() => {
                                    window.location.reload();
								}, 2000);
							}else{
								self.setType('red');
								self.setTitle('Error');
								self.setContent(response);
                            }
						}
            
					);
				}
			});
		});


    </script>
