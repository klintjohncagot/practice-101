<?php 
  require "./connect.php";
  session_start();
  unset($_SESSION["student_id"]);

  if(isset($_SESSION["student_id"])) {
    header("Location: ./student/student_home.php");
  } else {
    header("Location: .././index.php");
  }
?>