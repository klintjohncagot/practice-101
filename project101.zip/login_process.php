<?php
    session_start();
    include './connect.php';
    date_default_timezone_set('Asia/Manila');
    $date_login = date("Y-m-d");
    $time_login = date("h:i A");


    $login_email = $_POST['login_email'];
    $login_password  = $_POST['login_password'];

    // students
    $auth = "SELECT * FROM student WHERE email = '$login_email'";
    $result = mysqli_query($conn,$auth);
    $row =  mysqli_fetch_assoc($result);
    $student_id = $row['student_id'];

    if(!mysqli_num_rows($result) > 0){
        echo json_encode("Account don't exist.");
    }else{

        if(password_verify($login_password, $row['password'])){
            $_SESSION['student_id'] = $row['student_id'];

            echo json_encode("success");
        }else{
            // echo json_encode(mysqli_error($conn));
            echo json_encode("Incorrect password");
        } 
    }
    
    
?>