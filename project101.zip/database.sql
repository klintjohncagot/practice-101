CREATE DATABASE project;
USE project;

CREATE TABLE student(
    student_id INT(100),
    first_name VARCHAR(255),
    last_name VARCHAR(255),
    gender ENUM('M','F'),
    email VARCHAR(255),
    password VARCHAR(255),
    year_level ENUM('1','2','3','4'),
    major VARCHAR(255),
    date_added date,
    time_added VARCHAR(255)
);

ALTER TABLE student
  ADD PRIMARY KEY (student_id);

ALTER TABLE student
  MODIFY student_id int(100) NOT NULL AUTO_INCREMENT;
