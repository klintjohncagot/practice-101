<?php

        session_start();
        require('connect.php');
        date_default_timezone_set('Asia/Manila');

        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $gender = $_POST['gender'];
        $year_level  = $_POST['year_level'];
        $major  = $_POST['major'];
        $email  = $_POST['email'];
        $password  = $_POST['password'];
        $date_added = date("Y-m-d");
        $time_added = date("h:i A");

        // regex for inputed numbers
        $Regex = "/[0-9]/";

        // check if email has duplicate
        $check_duplicate_email= "SELECT email FROM student WHERE email = '$email'";
        $result_email = mysqli_query($conn, $check_duplicate_email);
        $count_email = mysqli_num_rows($result_email);

        // check if first name and last name are the same
        $check_duplicate_fullname = "SELECT first_name, last_name FROM student WHERE first_name = '$first_name' && last_name ='$last_name'";
        $result_fullname = mysqli_query($conn, $check_duplicate_fullname);
        $count_name = mysqli_num_rows($result_fullname);

        if($password == "" || empty($password)) {
            echo json_encode("Please enter a password.");
            return false;
        }else if($count_email > 0){
            echo json_encode("Email is already taken. Please use another email.");
            return false;
        }else if($count_name > 0){
            echo json_encode("Your name is already taken. Please log in to your existing account.");
            return false;
        }else if(strlen($password) > 20){
            echo json_encode("Password is too long. Maximum of 20 characters only.");
            return false;
        }else if (preg_match($Regex, $first_name, $match)){
            echo json_encode("Please enter a valid first name.");
            return false;
        }else if (preg_match($Regex, $last_name, $match)){
            echo json_encode("Please enter a valid last name.");
            return false;
        }else{
                    // success query
                    $password_encryption = password_hash($password, PASSWORD_DEFAULT);
                    $sql = "INSERT INTO `student` (first_name,last_name,gender,year_level,major,email,password,date_added,time_added)
                            VALUES ('$first_name', '$last_name', '$gender', '$year_level', '$major', '$email', '$password_encryption','$date_added','$time_added')";
                    $query_run = mysqli_query($conn, $sql);
                    
                    if($query_run){
                        echo json_encode("success");
                    }else{	
                        echo json_encode(mysqli_error($conn));
                    };
        } 




?>