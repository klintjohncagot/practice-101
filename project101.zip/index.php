<?php
    //connection to the database
    session_start();
    require('connect.php');
?>
<html>
    <head>
        <meta charset="UTF-8">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
        <title>INDEX</title>
        <link href="css/style.min.css" rel="stylesheet">
        <link href="css/theme-colors.css" rel="stylesheet">
        <!-- Bootstrap core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <!-- Your custom styles (optional) -->
        <link href="css/mdb.min.css" rel="stylesheet">
        <link href="css/style.min.css" rel="stylesheet">
        <!-- <link rel="icon" href="./mobile/img/gym_logo.png"> -->
        <!-- <link href="index_admin.css" rel="stylesheet"> -->
        <link href="css/theme-colors.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
    </head>
    <style>
    
    </style>
    <body class="bg-dark">
        <div class="card mx-auto mt-5 bg-light" style="width: 50%">
            <div class="card-body">


                <div class="container">
                    <div class="row">
                        <div class="col-6 text-center">
                            <button class="btn btn-success" type="button" id="login_toggle" onclick = "login()" style="width: 95%">Sign In</button>
                        </div>
                        <div class="col-6 text-center">
                            <button class="btn btn-primary"  type="button" id="register_toggle" onclick="register()" style="width: 95%">Register</button>
                        </div>
                    </div>
                </div>


                <div id="login" class="login mx-auto mt-5" style="width: 94%; display:block;">
                        <div class="form-group">
                            <label>Email address</label>
                            <input type="email" id="login_email" class="form-control" id=""  placeholder="Enter email">
                            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input type="password" id="login_password" class="form-control" id="" placeholder="Password">
                        </div>
                        <button type="submit" id="login-submit" class="btn btn-primary">Submit</button>
                </div>

                <div id="register" class="register mx-auto mt-5" style="width: 94%; display:none;">
                <form action="register_process.php" id="register_process" method="post" enctype="multipart/form-data">
                    <div class="container">
                        <div class="row">
                            <div class="col-6">
                                <label>Firstname</label>
                                <input name="first_name" type="text" class="form-control" placeholder="First name">
                            </div>
                            <div class="col-6">
                                <label>Lastname</label>
                                <input name="last_name" type="text" class="form-control" placeholder="Last name">
                            </div>
                        </div>
                    </div>
                    <br />
                    <div class="container">
                        <div class="row">
                            <div class="col-3">
                                <label>Gender</label> <br />
                                <select name="gender" class="form-control" aria-label="Default select example">
                                    <option selected>Gender</option>
                                    <option value="M">Male</option>
                                    <option value="F">Female</option>
                                </select>
                            </div>
                            <div class="col-3">
                                <label>Year Level</label> <br />
                                <select name="year_level" class="form-control" aria-label="Default select example">
                                    <option selected>Year level</option>
                                    <option value="1">1st year</option>
                                    <option value="2">2nd year</option>
                                    <option value="3">3rd year</option>
                                    <option value="4">4th year</option>
                                </select>
                            </div>
                            <div class="col-6">
                                <label>Major taken</label>
                                <input name="major" type="text" class="form-control" placeholder="Major taken">
                            </div>
                        </div>
                    </div>
                    <br />
                    <div class="container">
                        <div class="row">
                            <div class="col-6">
                                <label>Email</label>
                                <input name="email" type="email" class="form-control" placeholder="Email address">
                            </div>
                            <div class="col-6"> 
                                <label>Password</label>
                                <input name="password" type="text" class="form-control" placeholder="Password">
                            </div>
                        </div>
                    </div> <br />
                    <button type="submit" class="btn btn-primary ml-3">Submit</button>
                    </form>
                </div>

            </div>
        </div>

    </body>
</html>

<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>
    <script type="text/javascript" src="js/popper.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/mdb.min.js"></script>
    <script type="text/javascript" src="validation.js"></script>
    <script src="./../js/pagination.js"></script>
    <script>


        function register() {
            // console.log("test");
            $('#register_toggle').removeClass('btn btn-primary').addClass('btn btn-success');
            $('#login_toggle').removeClass('btn btn-success').addClass('btn btn-primary');
            var register = document.getElementById("register");

            if(register.style.display === "none"){
                $(".login").hide();
                $(".register").toggle();
            }else if(register.style.display === "block"){
                $(".login").hide();
                $(".register").toggle();
            }
        }

        function login() {
            // console.log("test");
            $('#login_toggle').removeClass('btn btn-primary').addClass('btn btn-success');
            $('#register_toggle').removeClass('btn btn-success').addClass('btn btn-primary');
            var login = document.getElementById("login");

            if(login.style.display === "none"){
                $(".register").hide();
                $(".login").toggle();
            }else if(register.style.display === "block"){
                $(".register").hide();
                $(".login").toggle();
            }
        }


        $("#register_process").submit(function(e) {
            e.preventDefault();
            let url = $(this).attr("action");
            let data = new FormData();
            // data.append('image', $("#fileButton_category").prop('files')[0]);
            let arr = $(this).serializeArray();

            arr.forEach(row => {
                data.append(row.name, row.value);
            });

            $.dialog({
                backgroundDismiss: true,
                closeIcon: false,
                content: function() {
                    var self = this;

                    return $.ajax({
                        url: url,
                        data: data,
                        cache: false,
                        contentType: false,
                        processData: false,
                        type: 'post',
                        success: function(res) {
                            console.log(res);
                            if (JSON.parse(res) == "success") {
                                self.setTitle("Success");
                                self.setContent("Student Successfully added.");
                                self.setType("green");
                                self.backgroundDismiss = () => window.location.reload();

                            }else {
                                self.setTitle("Error");
                                self.setContent(JSON.parse(res));
                                self.setType("red");
                            }
                        }
                    });
                }
            });
        });


        $("#login-submit").click(function () {
			$.confirm({
				type: 'modern',
				content: function () {
					var self = this;
					return $.post(
						"./login_process.php",
						{
							login_email: $("#login_email").val(),
							login_password: $("#login_password").val()
						},
                        
						function (res) {
                            console.log(res);
                            console.log(JSON.parse(res));
                            var response = JSON.parse(res);

                            if(response == "success") {
								self.setTitle('Success');
								self.setIcon('fa fa-spinner fa-spin');
								self.setContent('Please wait...');
								self.buttons.close.hide();
								setTimeout(() => {
									window.location.href = "./student/student_home.php";
								}, 2000);
							}else{
								self.setType('red');
								self.setTitle('Error');
								self.setContent(response);
                            }
						}
            
					);
				}
			});
		});


    </script>
